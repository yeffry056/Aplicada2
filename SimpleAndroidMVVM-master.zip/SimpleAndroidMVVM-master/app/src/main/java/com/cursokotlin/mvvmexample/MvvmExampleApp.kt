package com.cursokotlin.mvvmexample

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MvvmExampleApp:Application()