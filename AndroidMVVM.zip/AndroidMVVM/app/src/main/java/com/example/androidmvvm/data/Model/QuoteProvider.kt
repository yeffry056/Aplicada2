package com.example.androidmvvm.data.Model

class QuoteProvider {
    companion object {


        var quotes:List<QuoteModel> = emptyList()
    }
}