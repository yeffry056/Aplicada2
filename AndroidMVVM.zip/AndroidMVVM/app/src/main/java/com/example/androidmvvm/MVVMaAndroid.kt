package com.example.androidmvvm

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

//esta sera la primera en ejecutarse cuando inicie la app
//@HiltAndroidApp
class MVVMaAndroid:Application()